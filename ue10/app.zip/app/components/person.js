//Kaiser Stefan 4BI
"use strict";

app.component("person", {
    templateUrl: "components/person.html",
    controller: "personeneditor",
    bindings: {
        name:"@",
        plaetze:"<",
        gereiht:"&",
        ungereiht:"&"
    }
});

app.controller("personeneditor", function () {
    let $ctrl = this;
    $ctrl.$onInit = function () {
        $ctrl.plaetze = this.plaetze;
    };
    $ctrl.platz();
});