//Kaiser Stefan 4BI
"use strict";

app.component("reihung", {
    templateUrl: "components/reihung.html",
    controller: "reihungeditor",
    bindings: {
    }
});

app.controller("reihungeditor", function () {
    let $ctrl = this;

    $ctrl.namen = [
        "Max Mustermann",
        "Franz Josef",
        "Simon Garfunkel",
        "Heinz Zainzinger",
        "Herbert Pröll",
        "Sebastian Kern",
        "Albert Nietsche",
        "Sun Tsu"
    ];

    $ctrl.namen.length = Math.floor(Math.random() * 6) + 3;
    $ctrl.platzarray = [];

    for(var i=1;i<=$ctrl.namen.length;i++){
        $ctrl.platzarray.push(i);
    }
});