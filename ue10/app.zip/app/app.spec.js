"use strict";

describe("Vorlage", function() {

    it("ist testbar mit Karma/Jasmine", function() {
        expect(true).toEqual(true);
    });
});
